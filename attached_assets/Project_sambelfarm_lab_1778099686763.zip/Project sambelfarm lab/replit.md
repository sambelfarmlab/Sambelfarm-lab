# Sambelfarm Content Lab

AI-powered content creation tool for SambelFarm — generate TikTok/Reels scripts, brainstorm ideas, analyze viral potential with TRIBE v2, and save to Notion.

## Architecture

- **Frontend**: React + Vite (`artifacts/sambelfarm/`) at `/`
- **Backend**: Express API server (`artifacts/api-server/`) at `/api`

## Features

- **Auth**: Login page + HMAC-based password protection. Token stored in `localStorage` (`sf_auth_token`).
- **Home**: Dashboard with history from Notion database + stats
- **Butuh Ide?**: Brainstorm 5 content ideas via Claude AI given a keyword
- **Generator**: Generate full video scripts — Jenis Konten (Reels/Stories/Feed Post/Carousel), Tone (Storytelling/Edukatif/Promosi/Nyeleneh/Roasting), uses DNA style + custom prompt structure
- **Editor & TRIBE v2**: Edit scripts + viral score analysis with neuroscience engine + multi-platform captions
- **Kalender**: Monthly content calendar (localStorage-backed schedule with platform/status tracking)
- **Pengaturan**: DNA Style .txt upload + custom prompt structure + Notion DB ID config

## Environment Secrets

- `ANTHROPIC_API_KEY` — Claude API key (for AI generation)
- `NOTION_API_KEY` — Notion integration token (for saving/loading history)
- `SESSION_SECRET` — Used for HMAC-SHA256 token generation
- `ADMIN_PASSWORD` — Admin login password

## Auth Flow

Token = HMAC-SHA256(SESSION_SECRET, ADMIN_PASSWORD) — stateless, no DB needed.
All `/api/claude`, `/api/notion/*` routes require `Authorization: Bearer {token}` header.
Routes: `POST /api/auth/login`, `GET /api/auth/me`.

## User Configuration (Settings Tab)

Users configure via the **Pengaturan** tab (stored in `localStorage` as `sf_config`):
- `dbId` — Notion Database ID
- `dnaStyle` — Custom DNA style text (uploaded from .txt file or typed manually)
- `customPrompt` — Custom prompt structure for script generation

Notion Database properties needed:
- `Topik` (Title), `Script` (Rich Text), `Status Revisi` (Select)
- `Skor Viralitas` (Number), `Analisis AI` (Rich Text), `Rekomendasi` (Rich Text)

## API Routes

- `GET /api/health` — Health check with key status
- `GET /api/healthz` — Simple health check
- `POST /api/auth/login` — Login endpoint (returns token)
- `GET /api/auth/me` — Token validation endpoint
- `POST /api/claude` — Claude API proxy [auth required]
- `POST /api/notion/query` — Notion database query proxy [auth required]
- `POST /api/notion/pages` — Notion page creation proxy [auth required]

## Style

Colors defined as CSS variables in `App.tsx`:
- `--sage`: #7D9D85 (primary green)
- `--terra`: #E2725B (accent red-orange)
- `--gold`: #C9A96E (secondary gold)
- Font: Plus Jakarta Sans
